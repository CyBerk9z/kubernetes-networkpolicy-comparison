#!/usr/bin/env bash
# Resume only the missing repeats. Old run1/run2 and original TSVs stay untouched.
set -euo pipefail
export TZ=JST-9
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/results/2026-10-15-resume"
for run in run3 run4; do
  for exp in EXP-004-netpol-ingress-matrix EXP-005-netpol-egress-matrix EXP-006-netpol-protocol-matrix; do
    [[ "$run" = run4 && "$exp" = EXP-004* ]] && continue
    for cni in flannel kindnet calico cilium; do
      [ "$(date +%H%M)" -lt 0945 ] || { echo 'Time limit: stop starting new CNI runs'; exit 2; }
      dir="$OUT/$run/$exp"
      mkdir -p "$dir"
      [ ! -e "$dir/$cni.tsv" ] || { echo "Refusing to overwrite $dir/$cni.tsv" >&2; exit 1; }
      echo "START $run $exp $cni $(date -Iseconds)"
      RESULTS_DIR="$dir" bash "$HERE/../$exp/run.sh" "$cni" > "$dir/$cni-console.log" 2>&1
      if grep -q $'\tERROR' "$dir/$cni.tsv"; then
        echo "ERROR result in $dir/$cni.tsv" >&2; exit 1
      fi
      date -Iseconds > "$dir/$cni.complete"
      echo "DONE  $run $exp $cni $(date -Iseconds)"
    done
  done
done
