#!/usr/bin/env bash
# EXP-005: Egress 系ケースを4 CNI に適用し、client-a（対象）/ client-b（対照）から到達性を実測
# 実行: bash run.sh [cni...]  （Git Bash。前提: EXP-004 の workload.yaml が適用済み）
set -uo pipefail
export MSYS_NO_PATHCONV=1
HERE="$(cd "$(dirname "$0")" && pwd)"
WAIT="${WAIT:-5}"   # ponytail: 反映待ちは固定秒（EXP-004 と同条件）
CNIS="${*:-flannel kindnet calico cilium}"
RESULTS_DIR="${RESULTS_DIR:-$HERE/results}"
mkdir -p "$RESULTS_DIR"

probe() {  # $1=ctx $2=pod $3=target -> ALLOW | DENY-TIMEOUT | DENY-REFUSED | DENY-DNS | ERROR:<msg>
  local out rc
  for try in 1 2 3; do
    out=$(kubectl --context "$1" -n np4 exec "$2" -- /agnhost connect "$3" --timeout=3s 2>&1); rc=$?
    printf 'case=%s args=%s rc=%s\n%s\n' "$c" "$*" "$rc" "$out" >> "$RAW_LOG"
    [ $rc -eq 0 ] && { echo ALLOW; return; }
    case "$out" in
      *lookup*|*"no such host"*) echo DENY-DNS; return;;
      *TIMEOUT*) echo DENY-TIMEOUT; return;;
      *REFUSED*) echo DENY-REFUSED; return;;
    esac
    sleep 2
  done
  echo "ERROR:$(echo "$out" | head -1 | tr '\t' ' ')"
}

run_cni() {
  local cni=$1 ctx=kind-netpol-$1 out="$RESULTS_DIR/$1.tsv" sip svc
  local log="$RESULTS_DIR/$1-policies.log" RAW_LOG="$RESULTS_DIR/$1-probes.log"
  : > "$log"; : > "$RAW_LOG"
  sip=$(kubectl --context "$ctx" -n np4 get pod server -o jsonpath='{.status.podIP}') || return 1
  svc=$(kubectl --context "$ctx" -n np4 get svc server -o jsonpath='{.spec.clusterIP}') || return 1
  [ -n "$sip" ] && [ -n "$svc" ] || return 1
  echo -e "case\tsrc\tdst\tresult" > "$out"
  for c in E00-no-policy $(ls "$HERE/cases" | sed 's/\.yaml$//'); do
    printf '\nCASE %s\n' "$c" >> "$log"
    kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
    if [ -f "$HERE/cases/$c.yaml" ]; then
      sed "s/SVC_IP/$svc/; s/SERVER_IP/$sip/" "$HERE/cases/$c.yaml" | kubectl --context "$ctx" apply -f - >> "$log" 2>&1 || return 1
    fi
    kubectl --context "$ctx" -n np4 get networkpolicy -o yaml >> "$log" 2>&1 || return 1
    sleep "$WAIT"
    for s in a b; do
      for d in P80 P81 SVCIP SVCDNS EXT; do
        case $d in P80) t=$sip:80;; P81) t=$sip:81;; SVCIP) t=$svc:80;; SVCDNS) t=server.np4.svc.cluster.local:80;; EXT) t=1.1.1.1:443;; esac
        echo -e "$c\t$s\t$d\t$(probe "$ctx" client-$s "$t")" >> "$out"
      done
    done
    echo "[$cni] $c done"
  done
  kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
}

pids=()
for cni in $CNIS; do run_cni "$cni" & pids+=("$!"); done
rc=0
for pid in "${pids[@]}"; do wait "$pid" || rc=1; done
[ "$rc" -eq 0 ] || exit "$rc"
echo "all done -> PYTHONIOENCODING=utf-8 python summarize.py"
