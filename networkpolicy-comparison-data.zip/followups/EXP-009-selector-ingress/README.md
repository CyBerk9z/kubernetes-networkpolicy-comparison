# EXP-009: IngressのPod選択に対するselector対処

検証したいこと：ipBlockにPod IPを含むIngressで生じるCNI間の挙動差について、試験対象の3 Podをselectorで明示選択すると、意図したA遮断・B/C許可が実現するか。

## 計画（測定前）

4 CNIの同じ保存クラスタ、既定設定、単一ノード、同一namespace構成・イメージ・5秒反映待ち・3秒接続タイムアウトで比較する。独立変数はPolicyの指定方法（ipBlockとselector）で、CNIは比較層として別集計する。Policyなし基準を各反復の最初に測り、基準が不通ならその反復を無効とする。3送信元×Pod IP:80/81とService IP:80の9プローブ、基準・ipBlock・selector各1組を4回、4 CNIで432プローブ予定。既存の結果は上書きしない。

A（同namespace・app=client）を除外しB（同namespace・app=other）とC（別namespace・app=client）を許可する。ipBlockは0.0.0.0/0からAの現在のPod IPを除く。selectorはBのappラベル、Cのnamespace名とappラベルを選ぶ。Aは選択せず、Aに似た非対象Podがない制約で検証する。外部IPや追加Podを含む指定集合は等価ではない。DNS、Egressおよび動的ラベル変更は測定対象外。flannel単体はPolicy非実施の対照。

専用namespace np9-main / np9-otherのみを使用し、既存namespaceを再利用しない。既存同名namespaceがある場合は中止する。NetworkPolicyの適用と読み取り、IP取得、全Pod Ready、基準の通過を確認し、各プローブの終了コードと出力を残す。ERRORや不完全な反復は失敗として残し、遮断とみなさない。測定後は実験作成Policyのみ削除し、namespaceとワークロードは再現用に残す。ランタイム、ノード、CNIイメージ、IP、ポリシーを保存する。差異が生じても実装不具合とは直ちに断定しない。

Service宛の結果は本環境での観測であり一般的な変換順序の保証ではない。反復は同じクラスタでの実行で、再構築・他ノード・異なるCNI版での再現性を示さない。
