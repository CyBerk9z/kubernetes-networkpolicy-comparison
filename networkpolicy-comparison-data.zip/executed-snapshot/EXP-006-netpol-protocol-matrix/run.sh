#!/usr/bin/env bash
# EXP-006: プロトコル（TCP/UDP/SCTP/ICMP）× 送信元（通常 Pod / hostNetwork Pod）を4 CNI で実測
# 実行: bash run.sh [cni...]  （前提: EXP-004 と EXP-006 の workload.yaml が適用済み）
set -uo pipefail
export MSYS_NO_PATHCONV=1
HERE="$(cd "$(dirname "$0")" && pwd)"
WAIT="${WAIT:-5}"   # ponytail: 反映待ちは固定秒（EXP-004/005 と同条件）
CNIS="${*:-flannel kindnet calico cilium}"
RESULTS_DIR="${RESULTS_DIR:-$HERE/results}"
mkdir -p "$RESULTS_DIR"

probe() {  # $1=ctx $2=pod $3=ip $4=TCP|UDP|SCTP|ICMP -> ALLOW | DENY-TIMEOUT | DENY-REFUSED | DENY | ERROR:<msg>
  local out rc
  for try in 1 2 3; do
    case $4 in
      TCP)  out=$(kubectl --context "$1" -n np4 exec "$2" -- /agnhost connect "$3:8080" --protocol=tcp --timeout=3s 2>&1);;
      UDP)  out=$(kubectl --context "$1" -n np4 exec "$2" -- /agnhost connect "$3:8081" --protocol=udp --timeout=3s 2>&1);;
      SCTP) out=$(kubectl --context "$1" -n np4 exec "$2" -- /agnhost connect "$3:8082" --protocol=sctp --timeout=3s 2>&1);;
      ICMP) out=$(kubectl --context "$1" -n np4 exec "$2" -- ping -c1 -W2 "$3" 2>&1) || out="$out PINGFAIL";;
    esac; rc=$?
    printf 'case=%s args=%s rc=%s\n%s\n' "$c" "$*" "$rc" "$out" >> "$RAW_LOG"
    [ $rc -eq 0 ] && [[ "$out" != *PINGFAIL* ]] && { echo ALLOW; return; }
    case "$out" in *TIMEOUT*) echo DENY-TIMEOUT; return;; *REFUSED*) echo DENY-REFUSED; return;; *"100% packet loss"*) echo DENY; return;; esac
    sleep 2
  done
  echo "ERROR:$(echo "$out" | head -1 | tr '\t' ' ')"
}

run_cni() {
  local cni=$1 ctx=kind-netpol-$1 out="$RESULTS_DIR/$1.tsv" ip
  local log="$RESULTS_DIR/$1-policies.log" RAW_LOG="$RESULTS_DIR/$1-probes.log"
  : > "$log"; : > "$RAW_LOG"
  ip=$(kubectl --context "$ctx" -n np4 get pod proto -o jsonpath='{.status.podIP}') || return 1
  [ -n "$ip" ] || return 1
  echo -e "case\tsrc\tdst\tresult" > "$out"
  for c in P00-no-policy $(ls "$HERE/cases" | sed 's/\.yaml$//'); do
    printf '\nCASE %s\n' "$c" >> "$log"
    kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
    if [ -f "$HERE/cases/$c.yaml" ]; then
      kubectl --context "$ctx" apply -f - < "$HERE/cases/$c.yaml" >> "$log" 2>&1 || return 1
    fi
    kubectl --context "$ctx" -n np4 get networkpolicy -o yaml >> "$log" 2>&1 || return 1
    sleep "$WAIT"
    for s in a h; do
      for d in TCP UDP SCTP ICMP; do
        echo -e "$c\t$s\t$d\t$(probe "$ctx" client-$s "$ip" $d)" >> "$out"
      done
    done
    echo "[$cni] $c done"
  done
  kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
}

pids=()
for cni in $CNIS; do run_cni "$cni" & pids+=("$!"); done
rc=0
for pid in "${pids[@]}"; do wait "$pid" || rc=1; done
[ "$rc" -eq 0 ] || exit "$rc"
echo "all done -> PYTHONIOENCODING=utf-8 python summarize.py"
