#!/usr/bin/env bash
# EXP-004: 同一ケース群を4 CNI に適用し、到達性を実測する（独立変数=CNI のみ）
# 実行: bash run.sh            （Git Bash。4クラスタ並列、所要 ~10分）
#       bash run.sh cilium     （1 CNI だけ）
# 出力: results/<cni>.tsv（生データ） → python summarize.py で比較表
set -uo pipefail
export MSYS_NO_PATHCONV=1
HERE="$(cd "$(dirname "$0")" && pwd)"
WAIT="${WAIT:-5}"   # ponytail: ポリシー反映待ちは固定秒。反映遅延を測るなら別実験で
CNIS="${*:-flannel kindnet calico cilium}"
RESULTS_DIR="${RESULTS_DIR:-$HERE/results}"
mkdir -p "$RESULTS_DIR"

probe() {  # $1=ctx $2=ns $3=pod $4=target -> ALLOW | DENY-TIMEOUT | DENY-REFUSED | ERROR
  local out rc
  for try in 1 2 3; do
    out=$(kubectl --context "$1" -n "$2" exec "$3" -- /agnhost connect "$4" --timeout=3s 2>&1); rc=$?
    printf 'case=%s args=%s rc=%s\n%s\n' "$c" "$*" "$rc" "$out" >> "$RAW_LOG"
    [ $rc -eq 0 ] && { echo ALLOW; return; }
    case "$out" in *TIMEOUT*) echo DENY-TIMEOUT; return;; *REFUSED*) echo DENY-REFUSED; return;; esac
    sleep 2
  done
  echo "ERROR"
}

run_cni() {
  local cni=$1 ctx=kind-netpol-$1 out="$RESULTS_DIR/$1.tsv"
  local log="$RESULTS_DIR/$1-policies.log" RAW_LOG="$RESULTS_DIR/$1-probes.log"
  : > "$log"; : > "$RAW_LOG"
  local sip aip
  sip=$(kubectl --context "$ctx" -n np4 get pod server -o jsonpath='{.status.podIP}') || return 1
  aip=$(kubectl --context "$ctx" -n np4 get pod client-a -o jsonpath='{.status.podIP}') || return 1
  [ -n "$sip" ] && [ -n "$aip" ] || return 1
  echo -e "case\tsrc\tdst\tresult" > "$out"
  for c in C00-no-policy $(ls "$HERE/cases" | sed 's/\.yaml$//'); do
    printf '\nCASE %s\n' "$c" >> "$log"
    kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
    if [ -f "$HERE/cases/$c.yaml" ]; then
      sed "s/CLIENT_A_IP/$aip/" "$HERE/cases/$c.yaml" | kubectl --context "$ctx" apply -f - >> "$log" 2>&1 || return 1
    fi
    kubectl --context "$ctx" -n np4 get networkpolicy -o yaml >> "$log" 2>&1 || return 1
    sleep "$WAIT"
    for s in a b c; do
      ns=np4; [ $s = c ] && ns=np4-other
      for d in P80 P81 S80; do
        case $d in P80) t=$sip:80;; P81) t=$sip:81;; S80) t=server.np4.svc.cluster.local:80;; esac
        echo -e "$c\t$s\t$d\t$(probe "$ctx" $ns client-$s "$t")" >> "$out"
      done
    done
    echo "[$cni] $c done"
  done
  kubectl --context "$ctx" -n np4 delete networkpolicy --all >> "$log" 2>&1 || return 1
}

pids=()
for cni in $CNIS; do run_cni "$cni" & pids+=("$!"); done
rc=0
for pid in "${pids[@]}"; do wait "$pid" || rc=1; done
[ "$rc" -eq 0 ] || exit "$rc"
echo "all done -> python summarize.py"
